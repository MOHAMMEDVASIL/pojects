<?php
    include 'connect.php';
    
 if(isset($_GET['da'])){
    $id=$_GET['da'];

$query="delete from shoes where Id= $id";

$result=mysqli_query($conn,$query);

if($result){
    header ('location:shoes_admin.php');
}
else{
    echo 'error';
}
 }
 else{
    echo 'value error';
 } 
 

 ?>