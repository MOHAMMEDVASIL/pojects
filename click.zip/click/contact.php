<?php
  include 'connect.php';

  if(isset($_POST["submit"])){
      
      $NAME=$_POST["cname"];
      $PHONE=$_POST["cphone"];
      $EMAIL=$_POST["cemail"];
      $MESSAGE=$_POST["cmessage"];
      /*echo $NAME,$PHONE,$EMAIL,$MESSAGE;*/

  $query="INSERT INTO contact_us
  (cname,pnom,cemail,cmessage)
  values('$NAME','$PHONE','$EMAIL','$MESSAGE')";

    if(mysqli_query($conn, $query)){
        echo "<script>alert('send message');</script>";
    }
    else{
        echo "<script>alert('query error');</script>";
    }
  }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact_us</title>


    <link rel="stylesheet" href="css/contact.css">    
</head>
<body>
  <!----header-->
  <div class="head">
       
       <nav>
           <div class="logo">    
           <img src="../click/img/index/logo.png">
           <span>Click & Collect </span>
       </div>
   
       <ul>
         <li><a href="index.html">Home</a></li>
         <li><a href="#">About</a></li>
         <li><a href="contact.php">Contact Us</a></li>
         <li><a href="#">Blog</a></li>
       </ul>
   </nav>
   
  

    <section class="itemback" id="contact-us">
        <div class="contact-form">
          <div class="flyer">
           <div class="mapouter">
            <div class="gmap_canvas">
              <iframe class="gmap_iframe" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=600&amp;height=400&amp;hl=en&amp;q=7.360676,81.796089&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
              <a href="https://formatjson.org/word-counter"></a></div>
              </div>
          </div>
          <form action="" method="post">
              <div class="txtbox">
                  <p>Contact-us</p>
              <input type="text" name="cname" id="cname" placeholder="Your Name">
              <input type="text" name="cphone" id="cphone"  placeholder="Phone no">
              <input type="email" name="cemail" id="cemail" placeholder="Email Address">
              <textarea type="text" name="cmessage" id="cmessage" placeholder="Message"  rows="3"></textarea>
              <button class="submit" name="submit">Submit</button>
              </div>
          </form>
          </div>
        </Section>
</body>
</html>