<?php

?>
<body>

    <!-- =============== Navigation ================ -->
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="logo">
                            <img src="../click/img/index/logo.png">
                        </span>
                        <span class="title-l"><span class="cl">Click</span> & Collect</span>
                    </a>
                </li>

                <li>
                    <a href="../html/dashboard.html">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="customer_admin.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Customers</span>
                    </a>
                </li>

                <li>
                    <a href="../html/product_upload.html">
                        <div class="icon">
                            <ion-icon name="cloud-upload-outline"></ion-icon>
                        </div>
                
                        <div class="drop">
                            Product Upload</a>
                        <div class="drop-menu">
                            <a href="sho_upload.php">Shoes</a>
                            <a href="watches_upload.php">Watches</a>
                            <a href="cosmatics_upload.php">Cosmatics</a>
                            <a href="#">updates</a>
                          </div>
                        </div>
             
                    </li> 
                
                    <li>
                        <a href="#">
                            <div class="icon">
                                <ion-icon name="eye-outline"></ion-icon>
                            </div>
                    
                            <div class="drop">
                                Product View</a>
                            <div class="drop-menu">
                                <a href="shoes_admin.php">Shoes</a>
                                <a href="watches_admin.php">Watches</a>
                                <a href="cosmatics_admin.php">Cosmatics</a>
                                <a href="#">updates</a>
                              </div>
                            </div>
                 
                        </li> 


                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="reorder-three-outline"></ion-icon>
                        </span>
                        <span class="title">Order Status</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
            </ul>
        </div>

</body>

</html>