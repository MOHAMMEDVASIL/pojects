<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>

  <link rel="stylesheet" href="css/index.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

    <!----header-->
    <div class="head">
       
    <nav>
        <div class="logo">    
        <img src="../click/img/index/logo.png">
        <span>Click & Collect </span>
    </div>

    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="#">About</a></li>
      <li><a href="contact.php">Contact Us</a></li>
      <li><a href="#">Blog</a></li>
      <li><a href="login.php" class="btn0">Sign in</a></li>
    </ul>
</nav>

<div class="content">
    <h1 class="slide-left">Click<br>& Collect</h1>
    <p class="slide-left">Online Shopping System at Sri-Lanka</p>
    <div class="links slide-left ">
        <a href="#" class="btn">Read More</a>
        <a href="#" >Or Contact</a>
    </div>
</div>
        <!--Shoes-->

<section class="garden">
    <h1><b>SHOES ITEMS </b></h1><br>
    <a href="user_shoes.php"class="botton1"><B>VISIT MY PAGE</B></a>
   

    <div class="row">
        <div class="garden-col">
        <img src="../click/img/index/s2.jpeg">
         <div class="layer">
        <h3>Nike</h3>
         </div> 
        </div>
         <div class="garden-col">
            <img src="../click/img/shoes/sh6.png">
             <div class="layer">
            <h3>Reebok</h3>
             </div> 
        </div>
        <div class="garden-col">
            <img src="../click/img/index/s1.avif">
             <div class="layer">
            <h3>Adidas</h3>
             </div> 
        </div>
  
       
</section>

<!------Watches-->

<section class="wood">
    <h1><B>WATCHES ITEMS</B></h1>
    <a href="user_watches.php"class="botton1"><B>VISIT MY PAGE</B></a>


    <div class="row">
        <div class="wood-col">
        <img src="../click/img/index/w1.jpg">
         <div class="layer">
        <h3>Cartier Santos</h3>
         </div> 
        </div>
         <div class="wood-col">
            <img src="../click/img/index/w2.jpg">
             <div class="layer">
            <h3>Harry Winston</h3>
             </div> 
       
        </div>
        <div class="wood-col">
            <img src="../click/img/index/w3.webp">
             <div class="layer">
            <h3>Rolex</h3>
             </div> 
        </div>
</section>

<!------Cosmatics-->

<section class="weaving">
    <h1>COSMATICS</h1>
    <a href="user_cosmatics.php"class="botton1"><B>VISIT MY PAGE</B></a>


    <div class="row">
        <div class="weaving-col">
        <img src="../click/img/index/c1.webp">
         <div class="layer">
        <h3>Clinique</h3>
         </div> 
        </div>
         <div class="weaving-col">
            <img src="../click/img/index/c2.png">
             <div class="layer">
            <h3>Dove</h3>
             </div> 
       
        </div>
        <div class="weaving-col">
            <img src="../click/img/index/c3.png">
             <div class="layer">
            <h3>Estee Lauder</h3>
             </div> 
        </div>
</section>


<!----Greetting--->

<section class="act">
    <h1> Hi Guys, <br>
     can you need any details?<br>
      no confused.
         contact for us!</h1>
  <a href="contact.php" class="botton">contact us</a>

</section>

<!------footer-->

<section class="footer">
    <h4>About us</h4>
    <p>This is  Our first web page.<br> this page is very famous, 
        small Natural bussines in my home town. 
    </p>
    
        <div class="icon">
           <span class="fa fa-facebook"></span>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>
            <i class="fa fa-linkedin"></i>
    
        </div>
    <p>Create with<i class="fa fa-hart-o"></i> by:- Get Easy Way Company </p> 
   
    </section>
    </body>
    </html>