<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer_admin</title>
    
    <link rel="stylesheet" href="css/shoes_admin.css">
</head>

<body>

<?php


include "adnavig.php";

?>
     
           
  <!-- ========================= Main ==================== -->
  <div class="main">
      <div class="topbar">
          <div class="toggle">
              <ion-icon name="menu-outline"></ion-icon>
          </div>

          <div class="search">
              <label>
                  <input type="text" placeholder="Search here">
                  <ion-icon name="search-outline"></ion-icon>
              </label>
          </div>

          <div class="user">
              <img src="assets/imgs/customer01.jpg" alt="">
          </div>
      </div>


            <!-- ================ Order Details List ================= -->
            <div class="details">
                <div class="recentOrders">
                    <div class="cardHeader">
                        <h2>Customer Details...!</h2>
                    
                        <a href="user_shoes.php" class="btn">User Display</a>
             
                    </div>
                   
                  
                    <div class="tab">
                    <table>    
                        <tbody>
                            <?php
                              include 'connect.php'; 
                                $sql="select * from users";
                                $res=$conn->query($sql);
                                if($res->num_rows>0){
                                   while( $row=$res->fetch_assoc()){
                                    echo '
                            <tr>
                                <td>'.$row['uname'].'</td>
                                <td>'.$row['uemail'].'</td>
                                <td>'.$row['uaddress'].'</td> 
                                <td><a href="customer_dlt.php?da='.$row['uemail'].'"><button class="dlt1">Remove</button></a></td>
                            </tr> ';
                            }
                        }
                            else{
                                printf("didn't recod");
                            }
                    
       
                                
                        ?>
                        </thead> 
                        </tbody>
                    </table>
                    
                </div>
                </div>

        <!-- ================= ads ================ -->
                <div class="Ads">
                    <div class="ads">
                        <h2>Items Views....!</h2>   
                
<div class="slideshow-container">

    <div class="mySlides fade">
      <img src="./img/shoes/sh3.png" style="width:100%">  
    </div>
    
    <div class="mySlides fade">
      <img src="./img/watches/w1.png" style="width:100%">
    </div>
    
    <div class="mySlides fade">
      <img src="./img/shoes/sh10.png" style="width:100%"> 
    </div>
    
    <br>
    
    <div style="text-align:center">
      <span class="dot"></span> 
      <span class="dot"></span> 
      <span class="dot"></span> 
    </div>
</div>
    
    
   <!-- =========== Scripts =========  -->
   <script src="./js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>