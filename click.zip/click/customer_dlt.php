<?php
    include 'connect.php';
    
 if(isset($_GET['da'])){
    $id=$_GET['da'];

$query="delete from customer where Id= $uemail";

$result=mysqli_query($conn,$query);

if($result){
    header ('location:customer_admin.php');
}
else{
    echo 'error';
}
 }
 else{
    echo 'value error';
 } 
 

 ?>