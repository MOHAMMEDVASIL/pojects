<?php
include 'connect.php';

if(isset($_POST['submit'])){  
   
  $BNAME=$_POST['b_name'];
  $MNAME=$_POST['m_name'];
  $PRICE=$_POST['price'];
  $PIC=$_POST['pic'];
  

$query="INSERT INTO shoes
(	pname,bname,price,pic	) 
values('$MNAME','$BNAME','$PRICE','$PIC')";

if(mysqli_query($conn,$query)){
  header('location:sho_upload.php');
}
else{
    echo 'error';
}

}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shoes_Upload</title>
    
    <link rel="stylesheet" href="css/sho_upload.css">
</head>

<body>
 
 
<?php


include "adnavig.php";

?>
  <!-- ========================= Main ==================== -->
  <div class="main">
      <div class="topbar">
          <div class="toggle">
              <ion-icon name="menu-outline"></ion-icon>
          </div>

          <div class="search">
              <label>
                  <input type="text" placeholder="Search here">
                  <ion-icon name="search-outline"></ion-icon>
              </label>
          </div>

          <div class="user">
              <img src="../click/img/shoes/sh1.png" alt="">
          </div>
      </div>

  




            <!-- ================ Order Details List ================= -->
            <div class="details">
                <div class="recentOrders">
                    <div class="cardHeader">
                        <h2>Shoes Items Uploads...!</h2>
                        <a href="#" class="btn">User Display</a>    
                    </div>   

                    
                    <form action="" method="post">
                        <div class="form">
                          
                          <div class="user-input-box">
                            <label for="fullName">Brand Name</label>
                            <input type="text"
                                    name="b_name"
                                    placeholder="Enter the brand name"/>
                          </div>
                          <div class="user-input-box">
                            <label for="username">Model Name</label>
                            <input type="text"
                                    name="m_name"
                                    placeholder="Enter the model name"/>
                          </div>

                          <div class="user-input-box1">
                            <label for="fullName">Product Amount</label>
                            <input type="text"
                                    id="amo"
                                    name="price"
                                    placeholder="Enter the amount"/>
                          </div>
                          <div class="user-input-box2">
                            <label for="username">Product Image</label>
                            <input class="fi" type="file"
                                    id="img"
                                    name="pic"
                                    placeholder="Choose the Image"/>
                          </div>

                          <div class="submit">
                        <input class="btn1" type="submit" value="Upload" name="submit"/>
                        
                          </div>
                 
                    </div>
            </form> 
            </div>


 <!-- ================= ads ================ -->
 <div class="Ads">
     <div class="ads">
         <h2>Shoes_Views...!</h2>   
     
     
<div class="slideshow-container">

<div class="mySlides fade">
<img src="../click/img/shoes/sh1.png" style="width:100%">  
</div>

<div class="mySlides fade">
<img src="../click/img/shoes/sh3.png" style="width:100%">
</div>

<div class="mySlides fade">
<img src="../click/img/shoes/sh6.png" style="width:100%"> 
</div>

<br>

<div style="text-align:center">
<span class="dot"></span> 
<span class="dot"></span> 
<span class="dot"></span> 
</div>
</div>


<!-- =========== Scripts =========  -->
<script src="./js/main.js"></script>

<!-- ====== ionicons ======= -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

      
</body>

</html>