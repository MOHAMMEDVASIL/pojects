<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shoes_admin</title>
    
    <link rel="stylesheet" href="css/shoes_admin.css">
</head>

<body>

<?php


include "adnavig.php";

?>
     
           
  <!-- ========================= Main ==================== -->
  <div class="main">
      <div class="topbar">
          <div class="toggle">
              <ion-icon name="menu-outline"></ion-icon>
          </div>

          <div class="search">
              <label>
                  <input type="text" placeholder="Search here">
                  <ion-icon name="search-outline"></ion-icon>
              </label>
          </div>

          <div class="user">
              <img src="../click/img/shoes/sh1.png" alt="">
          </div>
      </div>


            <!-- ================ Order Details List ================= -->
            <div class="details">
                <div class="recentOrders">
                    <div class="cardHeader">
                        <h2>Shoes Products View...!</h2>
                    
                        <a href="#" class="btn">User Display</a>
             
                    </div>
                   
                  
                    <div class="tab">
                    <table>    
                        <tbody>
                            <?php
                              include 'connect.php'; 
                                $sql="select * from shoes";
                                $res=$conn->query($sql);
                                if($res->num_rows>0){
                                   while( $row=$res->fetch_assoc()){
                                    echo '
                            <tr>
                                <td><img src="img/shoes/'.$row['pic'].'"></td>
                                <td>'.$row['bname'].'</td>
                                <td>'.$row['pname'].'</td>
                                <td>'.$row['price'].'</td>
                                <td><a href="sho_dlt.php?da='.$row['id'].'"><button class="dlt1">Remove</button></a></td>
                            </tr> ';
                            }
                        }
                            else{
                                printf("didn't recod");
                            }
                    
       
                                
                        ?>
                        </thead> 
                        </tbody>
                    </table>
                    
                </div>
                </div>

        <!-- ================= ads ================ -->
                <div class="Ads">
                    <div class="ads">
                        <h2>Shoes Views....!</h2>   
                
<div class="slideshow-container">

    <div class="mySlides fade">
      <img src="../click/img/shoes/sh7.png" style="width:100%">  
    </div>
    
    <div class="mySlides fade">
      <img src="../click/img/shoes/sh8.png" style="width:100%">
    </div>
    
    <div class="mySlides fade">
      <img src="../click/img/shoes/sh11.png" style="width:100%"> 
    </div>
    
    <br>
    
    <div style="text-align:center">
      <span class="dot"></span> 
      <span class="dot"></span> 
      <span class="dot"></span> 
    </div>
</div>
    
    
   <!-- =========== Scripts =========  -->
   <script src="./js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>