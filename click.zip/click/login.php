<?php
  include 'connect.php';

  if(isset($_POST["sigup"])){
      
      $NAME=$_POST["name"];
      $ADDRESS=$_POST["address"];
      $EMAIL=$_POST["email"];
      $PASSWORD=$_POST["password"];
   
  $query="INSERT INTO users
  (uname,uemail,uaddress,upassword) 
  values('$NAME','$EMAIL','$ADDRESS','$PASSWORD')";
  
  if(mysqli_query($conn,$query)){
    echo"<script>alert('user created..');</script>";
  }
  
  else{
    echo "error";
  
  }   
  
}
?>

<?php
  if(isset($_POST["login"])){

$name=$_POST["email"];
$pass=$_POST["password"];

if($name!="" && $pass!=""){
    $sql="SELECT  upassword ,uemail FROM users WHERE  upassword ='$pass' AND uemail='$name'"; //sql select query
    $result= $conn->query($sql);
    if ($result->num_rows >=1){
        header("location:user_shoes.php"); //open the next html file
    }
    else{
        echo "<p>Invalid user name password</p>";
    }
}
else{
    echo "<p>Please Fill the Details";
}
  }

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Login</title>
  <!-- Custom Styles -->
  <link rel="stylesheet" href="./css/login.css">
  <script type="module" src="https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/ionic.esm.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
</head>
<body>
<div class="Account">
 <a href="./index.php" style="text-decoration: none; color:white;" ><i class="fa fa-close" id="close-cart" style="font-size: 25px; color: white;"></i></a>
<div class="container" id="container">
    <div class="form-container sing-up-container">
      <div class="form">
      <h1>Create Account</h1>
      <div class="social-container">
        <ion-icon name="logo-facebook"></ion-icon>
        <ion-icon name="logo-google"></ion-icon>
      </div>
            <form action="" method="POST">
            <span class="intext">or use your email for registration</span>
              <input type="text" name="name" placeholder="User name" required>
              <input type="email" name="email" placeholder="your email" required>
              <input type="text" name="address" placeholder="your Address" required>
              <input type="password" name="password" placeholder="your password" required>
              <button class="btnS" id="register" name="sigup">sign in</button>
            </form>
    </div>

  </div>
  
  <div class="form-container sing-in-container">
      <div class="form">
      <h1>Sign in</h1>
      <div class="social-container">
        <ion-icon name="logo-facebook"></ion-icon>
        <ion-icon name="logo-google"></ion-icon>
      </div>
      <span class="intext">use your account</span>
    <form action="" method="post">
      <input type="email" placeholder="Email" id="l-email" name="email">
      <input type="password" placeholder="Password" name="password" id="l-password">
      <button class="btnS" id="login" name="login">Login</button>
  </form>
    </div> 
  </div>
  <div class="overlay-container">
    <div class="overlay">
      <div class="overlay-panel overlay-left">
        <h6><span class="tage">Click</span> & Collect </h6>
        <h6><span class="tage"> Register Now</span></h6>
        
        <img class="left-img" src="../click/img/index/logo.png" alt="left-image">
        <button class="press btnS sigin " onclick="classRemove()">Sign In <i class='fa fa-arrow-right' style="padding: 0;"></i></button>
      </div>
      <div class="overlay-panel overlay-right">
        <h6><span class="tage">Click</span> </h6>
        <h6>& <span class="tage"> Collect</span></h6>
        
        <img class="left-img" src="../click/img/index/logo.png" alt="left-image">
        <button class="press btnS sigup"  onclick="classAdd()"><i class='fa fa-arrow-left' style="padding: 0;"></i> Sign Up</button>
      </div>
  </div>
</div>
</div>
</div>

   <script>
    
    const container =document.getElementById("container");
    
  
    function classAdd() {
    var element = document.getElementById("container");
    element.classList.add("right-panel-active");
    }
    function classRemove(){
      var moment =document.getElementById("container");
      moment.classList.remove("right-panel-active");
    }
 </script>

</body>



</html>