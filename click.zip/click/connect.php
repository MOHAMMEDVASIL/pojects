<?php
$conn=mysqli_connect('localhost','root','','click&collect');

if(!$conn){
    die('connection Error'.mysqli_connect_Error());
}
?>