<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>user_shoes</title>

  <link rel="stylesheet" href="css/user_shoes.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

    <!----header-->
    <div class="head">
      
    <nav>
        <div class="logo">    
        <img src="./img/index/logo.png">
        <span>Click & Collect </span>
    </div>

    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="#">About</a></li>
      <li><a href="contact.php">Contact Us</a></li>
      <li><a href="#">Blog</a></li>
      
    </ul>
</nav>
<div class="container">
    <header>
        <h1 class="he1">Shoes Items</h1>
        <div class="shopping">
            <img src="./img/index/logo.png">
            <span class="quantity">0</span>
        </div>
    </header>
    <div class="list">
  
  <?php
    $conn=mysqli_connect('localhost','root','','click&collect');

    if(!$conn){
        die('connection Error'.mysqli_connect_Error());
    }

     $sql="select * from shoes";
     $res=$conn->query($sql);
     if($res->num_rows>0){
       while ($row=$res->fetch_assoc()){
         echo "
        <div class='item'>
        <img src='./img/shoes/{$row["pic"]}' class='pimg'>
        <div class='title'>{$row["bname"]}</div>
        <div class='pname'>{$row["pname"]}</div>
        <div class='price'>{$row["price"]}</div>
        <button>Order Now</button>
        </div>
    ";
}
}
else{
    printf("didn't recod");
}
?>
</div>

</div>
<div class="card">
    <h1>Order Details</h1>
    <ul class="listCard">
    </ul>
    <div class="checkOut">
        <div class="total">0</div>
        <div class="closeShopping">Close</div>
    </div>
</div>

<!------footer-->

<section class="footer">
    <h4>About us</h4>
    <p>This is  my first web page.<br> this page is very famous, 
        small Natural busines in my home town. 
    </p>
    
        <div class="icon">
           <span class="fa fa-facebook"></span>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>
            <i class="fa fa-linkedin"></i>
    
        </div>
    <p>Create with<i class="fa fa-hart-o"></i> by:- Click & Collect (Pvt) Company </p> 
    <script src="./js/cus_shoes.js"></script>
    </section>
    </body>
    </html>